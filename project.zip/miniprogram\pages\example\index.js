// pages/example/index.js
Page({
  data: {
    message: '这是一个临时页面'
  },

  onLoad() {
    console.log('example页面加载')
  }
})
